#include "Plants.hpp"
#include "GameWorld.hpp"


void Plant::OnClick()
{
    if (m_pGameWorld->GetHandType() == TYPEID_SHOVEL)
    {
        SetHp(HP_DEAD);
        m_pGameWorld->SetHandType(TYPEID_HAND);
    }
}

void Sunflower::Update()
{
    if (GetHp() > 0)
    {
        if (m_pGameWorld->GetTick() % 600 == (m_plant_tick+m_initial_generating_time))
        {
            m_pGameWorld->Ctor(GetX(), GetY(), TYPEID_SUNFLOWERSUN);
        }
    }
}
void Peashooter::Update()
{
    if (GetHp() > 0)
    {
        if (m_cooler_time > 0)
        {
            m_cooler_time--;
        }
        else
        {
            if (m_pGameWorld->HaveZombie(GetX(), GetY()))
            {
                m_pGameWorld->Ctor(GetX() + 30, GetY() + 20, TYPEID_PEA);
                m_cooler_time = 30;
            }
        }
    }
}

void Wallnut::Update()
{
    if (GetHp() > 0)
    {
        if (GetHp() < m_hp / 3)
        {
            ChangeImage(IMGID_WALLNUT_CRACKED);
        }
    }
}

void CherryBomb::Update()
{
    if (GetHp() > 0)
    {
        
        if ((++m_waiting_time)== 15)
        {
            SetHp(HP_DEAD);
            m_pGameWorld->Ctor(GetX(), GetY(), TYPEID_EXPLOSION);
        }
    }
}

void Repeater::Update()
{
    if (GetHp() > 0)
    {
        if(m_cooler_time>0){
            m_cooler_time--;
            if(m_cooler_time==25){
                m_pGameWorld->Ctor(GetX() + 30, GetY() + 20, TYPEID_PEA);
            }
        }
        else{
            if(m_pGameWorld->HaveZombie(GetX(),GetY())){
                m_pGameWorld->Ctor(GetX() + 30, GetY() + 20, TYPEID_PEA);
                m_cooler_time = 30;
            }
        }
    }
}
