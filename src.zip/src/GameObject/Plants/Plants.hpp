#ifndef PLANTS_HPP__
#define PLANTS_HPP__

#include "GameObject.hpp"

class Plant : public GameObject
{
public:
    Plant(ImageID imageID, int x, int y, int hp, int type, pGameWorld ptr) : GameObject(imageID, x, y, LAYER_PLANTS, 60, 80, ANIMID_IDLE_ANIM, hp, type, ptr){};
    //void Update() override;
    void OnClick() override;
};

class Sunflower : public Plant
{
private:
    int m_plant_tick;
    int m_initial_generating_time;

public:
    Sunflower(int x, int y, pGameWorld ptr, int tick) : Plant(IMGID_SUNFLOWER, x, y, 300, TYPEID_SUNFLOWER, ptr), m_plant_tick(tick),m_initial_generating_time(randInt(30, 600)){};
    void Update() override;
};

class Peashooter : public Plant
{
private:
    int m_cooler_time;

public:
    Peashooter(int x, int y, pGameWorld ptr) : Plant(IMGID_PEASHOOTER, x, y, 300, TYPEID_PEASHOOTER, ptr),m_cooler_time(0){};
    void Update() override;
};

class Wallnut : public Plant
{
public:
    Wallnut(int x, int y, pGameWorld ptr) : Plant(IMGID_WALLNUT, x, y, 4000, TYPEID_WALLNUT, ptr){};
    void Update() override;
};

class CherryBomb : public Plant
{
private:
    int m_waiting_time;
public:
    CherryBomb(int x, int y, pGameWorld ptr) : Plant(IMGID_CHERRY_BOMB, x, y, 4000, TYPEID_CHERRYBOMB, ptr),m_waiting_time(0){};
    void Update() override;
};

class Repeater : public Plant
{
private:
    int m_cooler_time;
public:
    Repeater(int x, int y, pGameWorld ptr) : Plant(IMGID_REPEATER, x, y, 300, TYPEID_REPEATER, ptr),m_cooler_time(0){};
    void Update() override;
};
#endif // !PLANTS_HPP__