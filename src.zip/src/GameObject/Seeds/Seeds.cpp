#include "Seeds.hpp"
#include "GameWorld.hpp"



void Seed::OnClick()
{
    if (m_pGameWorld->GetHandType() == TYPEID_HAND 
    && m_pGameWorld->GetHandType() != TYPEID_COOLDOWNMASK 
    && m_pGameWorld->GetSun() >= GetPrice())
    {
        
        m_pGameWorld->Ctor(GetX(),GetY(),TYPEID_COOLDOWNMASK,m_CooldownTick);
        m_pGameWorld->SetSun(m_pGameWorld->GetSun()-GetPrice());
        m_pGameWorld->SetHandType(m_typeid);
    }
}
int Seed::GetPrice() const
{
    return m_price;
}
