#ifndef Seeds_HPP__
#define Seeds_HPP__

#include "GameObject.hpp"

class Seed : public GameObject
{
protected:
    int m_price;
    int m_CooldownTick;
public:
    Seed(ImageID imageID, int x, int y, int type, pGameWorld ptr,int price,int cdtick) : GameObject(imageID, x, y, LAYER_UI, 50, 70, ANIMID_NO_ANIMATION, HP_ALIVE, type, ptr),m_price(price),m_CooldownTick(cdtick){};
    int GetPrice()const;
    void OnClick() override;
};

class SunflowerSeed : public Seed
{
public:
    SunflowerSeed(pGameWorld ptr) : Seed(IMGID_SEED_SUNFLOWER, 130, WINDOW_HEIGHT - 44, TYPEID_SUNFLOWERSEED, ptr,PRICE_SUNFLOWER,240){};
    
};

class PeashooterSeed : public Seed
{
public:
    PeashooterSeed(pGameWorld ptr) : Seed(IMGID_SEED_PEASHOOTER, 190, WINDOW_HEIGHT - 44, TYPEID_PEASHOOTERSEED, ptr,PRICE_PEASHOOTER,240){};
    
};

class WallnutSeed : public Seed
{
public:
    WallnutSeed(pGameWorld ptr) : Seed(IMGID_SEED_WALLNUT, 250, WINDOW_HEIGHT - 44, TYPEID_WALLNUTSEED, ptr,PRICE_WALLNUT,900){};
    
};

class CherryBombSeed : public Seed
{
public:
    CherryBombSeed(pGameWorld ptr) : Seed(IMGID_SEED_CHERRY_BOMB, 310, WINDOW_HEIGHT - 44, TYPEID_CHERRYBOMBSEED, ptr,PRICE_CHERRYBOMB,1200){};
    
};

class RepeaterSeed : public Seed
{
public:
    RepeaterSeed(pGameWorld ptr) : Seed(IMGID_SEED_REPEATER, 370, WINDOW_HEIGHT - 44, TYPEID_REPETAERSEED, ptr,PRICE_REAPEATER,240){};
    
};

#endif // !Seeds_HPP__