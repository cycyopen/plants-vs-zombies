#include "GameObject.hpp"
#include "GameWorld.hpp"


void GameObject::Collision(){};
void GameObject::CollisionOver(){};

bool GameObject::IsZombie() const
{
    return (m_typeid == TYPEID_REGULAR || m_typeid == TYPEID_BUCKETHEAD || m_typeid == TYPEID_POLEVAULTING);
};
bool GameObject::IsPlant() const
{
    return (m_typeid == TYPEID_SUNFLOWER || m_typeid == TYPEID_PEASHOOTER || m_typeid == TYPEID_WALLNUT || m_typeid == TYPEID_CHERRYBOMB || m_typeid == TYPEID_REPEATER);
}
bool GameObject::CanCollision() const
{
    return (IsZombie() || IsPlant() || m_typeid == TYPEID_PEA || m_typeid == TYPEID_EXPLOSION);
};

void GameObject::SetHp(int Hp)
{
    m_hp = Hp;
}
int GameObject::GetHp() const
{
    return m_hp;
}
int GameObject::GetTypeid() const
{
    return m_typeid;
}

void Sun::Update()
{
    int flytime = m_pGameWorld->GetTick() - m_initial_tick;

    if ((m_typeid == TYPEID_SKYSUN) && (flytime < m_droptime)) // from sky
    {
        MoveTo(GetX(), GetY() - 2);
    }
    if ((m_typeid == TYPEID_SUNFLOWERSUN) && (flytime < m_droptime)) // m_typeid==TYPEID_SUNFLOWERSUN
    {
        MoveTo(GetX() - 1, GetY() + 4 - flytime);
    }
    if ((flytime >= m_droptime) && (m_pGameWorld->GetTick() == m_initial_tick + m_droptime + 300))
    {
        SetHp(HP_DEAD);
    }
}

void Sun::OnClick()
{
    m_pGameWorld->SetSun(m_pGameWorld->GetSun() + 25);
    SetHp(HP_DEAD);
}

void PlantingSpot::OnClick()
{
    if (m_pGameWorld->GetHandType() != TYPEID_HAND && m_pGameWorld->GetHandType() != TYPEID_SHOVEL)
    {
        m_pGameWorld->Ctor(GetX(), GetY(), m_pGameWorld->GetHandType());
        m_pGameWorld->SetHandType(TYPEID_HAND);
    }
}

void Shovel::OnClick()
{
    if (m_pGameWorld->GetHandType() == TYPEID_SHOVEL)
    {
        m_pGameWorld->SetHandType(TYPEID_HAND);
    }

    else if (m_pGameWorld->GetHandType() == TYPEID_HAND)
    {
        m_pGameWorld->SetHandType(TYPEID_SHOVEL);
    }
    else
    {
    }
}

void CooldownMask::Update()
{
    if (m_pGameWorld->GetTick() >= (m_CooldownTick + m_initial_tick))
    {
        SetHp(HP_DEAD);
    }
}

void Pea::Update()
{
    if (GetHp() > 0)
    {
        MoveTo(GetX() + 8, GetY());
        if (GetX() >= WINDOW_WIDTH)
        {
            SetHp(HP_DEAD);
        }
    }
}

void Explosion::Update()
{
    if ((++m_waiting_time) == 3)
    {
        SetHp(HP_DEAD);
    }
}