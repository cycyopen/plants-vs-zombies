#include "Zombies.hpp"
#include "GameWorld.hpp"

int Zombie::GetAction() const
{
    return m_action;
}
void Zombie::SetAction(int act)
{
    m_action = act;
}

void Zombie::Update()
{
    if (GetHp() > 0)
    {
        if (GetAction() == ACTION_WALK)
        {
            MoveTo(GetX() - 1, GetY());
        }
        if (GetAction() == ACTION_RUN)
        {
            MoveTo(GetX() - 2, GetY());
        }
    }
}
void Zombie::Collision()
{
    if (GetAction() == ACTION_WALK)
    {
        SetAction(ACTION_STOP);
        PlayAnimation(ANIMID_EAT_ANIM);
    }
}
void Zombie::CollisionOver()
{

    if (GetAction() == ACTION_STOP)
    {
        SetAction(ACTION_WALK);
        PlayAnimation(ANIMID_WALK_ANIM);
    }
}

void BucketHeadZombie::Update()
{
    if (GetHp() > 0)
    {
        if (GetAction() == ACTION_WALK)
        {
            MoveTo(GetX() - 1, GetY());
        }
        if (GetHp() <= 200)
        {
            ChangeImage(IMGID_REGULAR_ZOMBIE);
        }
    }
}

void PoleVaultingZombie::Update()
{
    if (GetHp() > 0)
    {
        if (GetAction() == ACTION_WALK)
        {
            MoveTo(GetX() - 1, GetY());
        }
        if (GetAction() == ACTION_RUN)
        {
            MoveTo(GetX() - 2, GetY());
        }
        if (GetAction() == ACTION_RUN && m_pGameWorld->CollisionBtwPZ(GetX() - 40, GetY()))
        {
            SetAction(ACTION_JUMP);
            PlayAnimation(ANIMID_JUMP_ANIM);
        }
        if (GetAction() == ACTION_JUMP && (m_jump_tick++) == 42)
        {
            SetAction(ACTION_WALK);
            PlayAnimation(ANIMID_WALK_ANIM);
            MoveTo(GetX() - 150, GetY());
        }
    }
}