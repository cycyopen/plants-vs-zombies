#ifndef Zombies_HPP__
#define Zombies_HPP__

#include "GameObject.hpp"

class Zombie : public GameObject
{
private:
    int m_action;

public:
    Zombie(ImageID imageID, int x, int y, AnimID animID, int hp, int type, pGameWorld ptr, int act) : GameObject(imageID, x, y, LAYER_ZOMBIES, 20, 80, animID, hp, type, ptr), m_action(act){};

    int GetAction() const;
    void SetAction(int);
    virtual void Collision() override;
    virtual void CollisionOver() override;
    void Update() override;
};

class RegularZombie : public Zombie
{

public:
    RegularZombie(int x, int y, pGameWorld ptr) : Zombie(IMGID_REGULAR_ZOMBIE, x, y, ANIMID_WALK_ANIM, 200, TYPEID_REGULAR, ptr, ACTION_WALK){};
};

class BucketHeadZombie : public Zombie
{

public:
    BucketHeadZombie(int x, int y, pGameWorld ptr) : Zombie(IMGID_BUCKET_HEAD_ZOMBIE, x, y, ANIMID_WALK_ANIM, 1300, TYPEID_BUCKETHEAD, ptr, ACTION_WALK){};
    void Update() override;
};

class PoleVaultingZombie : public Zombie
{
private:
    int m_jump_tick;
public:
    PoleVaultingZombie(int x, int y, pGameWorld ptr) : Zombie(IMGID_POLE_VAULTING_ZOMBIE, x, y, ANIMID_RUN_ANIM, 340, TYPEID_POLEVAULTING, ptr, ACTION_RUN),m_jump_tick(0){};
    void Update() override;
};

#endif // !Zombies_HPP__