#ifndef GAMEOBJECT_HPP__
#define GAMEOBJECT_HPP__

#include <memory>
#include "ObjectBase.hpp"

// Declares the class name GameWorld so that its pointers can be used.
class GameWorld;
using pGameWorld = std::shared_ptr<GameWorld>;

const int HP_ALIVE=1;
const int HP_DEAD=0;

const int TYPEID_BACKGROUND=0;
const int TYPEID_SKYSUN=1;
const int TYPEID_SUNFLOWERSUN=2;
const int TYPEID_PLANTINGSPOT=3;
const int TYPEID_PEA=4;
const int TYPEID_EXPLOSION=5;



const int TYPEID_SUNFLOWER=10;
const int TYPEID_PEASHOOTER=11;
const int TYPEID_WALLNUT=12;
const int TYPEID_CHERRYBOMB=13;
const int TYPEID_REPEATER=14;

const int TYPEID_SUNFLOWERSEED=100;
const int TYPEID_PEASHOOTERSEED=101;
const int TYPEID_WALLNUTSEED=102;
const int TYPEID_CHERRYBOMBSEED=103;
const int TYPEID_REPETAERSEED=104;
const int TYPEID_HAND=110;
const int TYPEID_SHOVEL=111;
const int TYPEID_COOLDOWNMASK=112;

const int TYPEID_REGULAR=1000;
const int TYPEID_BUCKETHEAD=1001;
const int TYPEID_POLEVAULTING=1002;

const int PRICE_SUNFLOWER=50;
const int PRICE_PEASHOOTER=100;
const int PRICE_WALLNUT=50;
const int PRICE_CHERRYBOMB=150;
const int PRICE_REAPEATER=200;

const int ACTION_STOP=20;
const int ACTION_WALK=21;
const int ACTION_RUN=22;
const int ACTION_JUMP=23;




class GameObject : public ObjectBase, public std::enable_shared_from_this<GameObject>
{
protected:
  int m_hp;
  int m_typeid;
  pGameWorld m_pGameWorld;

public:
  using std::enable_shared_from_this<GameObject>::shared_from_this; // Use shared_from_this() instead of "this".
  GameObject(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID, int hp, int type, pGameWorld ptr)
      : ObjectBase(imageID, x, y, layer, width, height, animID), m_hp(hp), m_typeid(type), m_pGameWorld(ptr){};

  virtual void Update() override{};
  virtual void OnClick() override{};

  virtual void Collision();
  virtual void CollisionOver();

  bool IsZombie() const;
  bool IsPlant() const;
  bool CanCollision() const;

  void SetHp(int Hp);
  int GetHp() const;
  int GetTypeid() const;

};

class Background : public GameObject
{
public:
  Background(pGameWorld ptr) : GameObject(IMGID_BACKGROUND, WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2, LAYER_BACKGROUND, WINDOW_WIDTH, WINDOW_HEIGHT, ANIMID_NO_ANIMATION, HP_ALIVE, TYPEID_BACKGROUND, ptr){};
};

class Sun : public GameObject
{
private:
  int m_droptime;
  int m_initial_tick;

public:
  Sun(int x, int y, int type, pGameWorld ptr, int droptime, int initial_tick) : GameObject(IMGID_SUN, x, y, LAYER_SUN, 80, 80, ANIMID_IDLE_ANIM, HP_ALIVE, type, ptr), m_droptime(droptime), m_initial_tick(initial_tick){};

  void Update() override;
  void OnClick() override;
};

class PlantingSpot : public GameObject
{
public:
  PlantingSpot(int x, int y, pGameWorld ptr) : GameObject(IMGID_NONE, x, y, LAYER_UI, 60, 80, ANIMID_NO_ANIMATION, HP_ALIVE, TYPEID_PLANTINGSPOT, ptr){};
  void OnClick() override;
};

class CooldownMask : public GameObject
{
private:
  int m_CooldownTick;
  int m_initial_tick;

public:
  CooldownMask(int x, int y, pGameWorld ptr, int cdtick, int initick) : GameObject(IMGID_COOLDOWN_MASK, x, y, LAYER_COOLDOWN_MASK, 50, 70, ANIMID_NO_ANIMATION, HP_ALIVE, TYPEID_COOLDOWNMASK, ptr), m_CooldownTick(cdtick), m_initial_tick(initick){};
  void Update() override;
};

class Pea : public GameObject
{
public:
  Pea(int x, int y, pGameWorld ptr) : GameObject(IMGID_PEA, x, y, LAYER_PROJECTILES, 28, 28, ANIMID_NO_ANIMATION, HP_ALIVE, TYPEID_PEA, ptr) {}
  void Update() override;
};

class Explosion : public GameObject
{
private:
  int m_waiting_time;

public:
  Explosion(int x, int y, pGameWorld ptr) : GameObject(IMGID_EXPLOSION, x, y, LAYER_PROJECTILES, 3 * LAWN_GRID_WIDTH, 3 * LAWN_GRID_HEIGHT, ANIMID_NO_ANIMATION, HP_ALIVE, TYPEID_EXPLOSION, ptr) {}
  void Update() override;
};

class Shovel : public GameObject
{
public:
  Shovel(pGameWorld ptr) : GameObject(IMGID_SHOVEL, 600, WINDOW_HEIGHT - 40, LAYER_UI, 50, 50, ANIMID_NO_ANIMATION, HP_ALIVE, TYPEID_SHOVEL, ptr){};
  void OnClick() override;
};



#endif // !GAMEOBJECT_HPP__
