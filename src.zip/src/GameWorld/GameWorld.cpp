#include "GameWorld.hpp"

#include "Plants.hpp"
#include "Zombies.hpp"
#include "Seeds.hpp"



GameWorld::GameWorld() {}

GameWorld::~GameWorld() {}

void GameWorld::Init()
{
  SetWave(0);
  SetSun(50);
  std::shared_ptr<GameObject> pBackground = std::make_shared<Background>(shared_from_this());
  objects.push_back(pBackground);
  m_tick = 0;
  m_waiting_time = 0;
  m_NextWave_tick = 1200;
  SetHandType(TYPEID_HAND);

  // Generate PlatingSpots
  for (int i = 0; i != GAME_COLS; ++i)
  {
    for (int j = 0; j != GAME_ROWS; ++j)
    {
      Ctor(FIRST_COL_CENTER + i * LAWN_GRID_WIDTH, FIRST_ROW_CENTER + j * LAWN_GRID_HEIGHT, TYPEID_PLANTINGSPOT);
    }
  }

  objects.push_back(std::make_shared<SunflowerSeed>(shared_from_this()));
  objects.push_back(std::make_shared<PeashooterSeed>(shared_from_this()));
  objects.push_back(std::make_shared<WallnutSeed>(shared_from_this()));
  objects.push_back(std::make_shared<CherryBombSeed>(shared_from_this()));
  objects.push_back(std::make_shared<RepeaterSeed>(shared_from_this()));
  objects.push_back(std::make_shared<Shovel>(shared_from_this()));
}

LevelStatus GameWorld::Update()
{
  TickUp();

  if (GetTick() % 300 == 180)
  {
    Ctor(randInt(75, WINDOW_WIDTH - 75), WINDOW_HEIGHT - 1, TYPEID_SKYSUN);
  }

  if ((m_waiting_time++) == m_NextWave_tick)
  {
    m_waiting_time = 0;
    SetWave(GetWave() + 1);
    m_NextWave_tick = (150 >= (600 - 20 * GetWave()) ? 150 : (600 - 20 * GetWave()));
    int TotZombies = (15 + GetWave()) / 10;
    int p1 = 20;
    int p2 = 2 * ((GetWave() - 8) > 0 ? (GetWave() - 8) : 0);
    int p3 = 3 * ((GetWave() - 15) > 0 ? (GetWave() - 15) : 0);
    int Random = randInt(1, p1 + p2 + p3);
    for (int i = 0; i < TotZombies; i++)
    {

      if (Random <= p1)
      {
        Ctor(randInt(WINDOW_WIDTH - 40, WINDOW_WIDTH - 1), FIRST_ROW_CENTER + LAWN_GRID_HEIGHT * randInt(0, 4), TYPEID_REGULAR);
      }
      else if (Random > p1 && Random <= p1 + p2)
      {
        Ctor(randInt(WINDOW_WIDTH - 40, WINDOW_WIDTH - 1), FIRST_ROW_CENTER + LAWN_GRID_HEIGHT * randInt(0, 4), TYPEID_BUCKETHEAD);
      }
      else if (Random > p1 + p2 && Random <= (p1 + p2 + p3))
      {
        Ctor(randInt(WINDOW_WIDTH - 40, WINDOW_WIDTH - 1), FIRST_ROW_CENTER + LAWN_GRID_HEIGHT * randInt(0, 4), TYPEID_POLEVAULTING);
      }
    }
  }

  for (auto it : objects)
  {
    it->Update();
  }

  for (auto it1 = objects.begin(); it1 != objects.end(); it1++)
  {
    for (auto it2 = it1; it2 != objects.end(); it2++)
    {
      if ((*it1)->CanCollision() || (*it2)->CanCollision())
      {
        bool CollisionHappen = CollisionJudge((*it1)->GetX(), (*it1)->GetY(), (*it1)->GetWidth(), (*it1)->GetHeight(), (*it2)->GetX(), (*it2)->GetY(), (*it2)->GetWidth(), (*it2)->GetHeight());
        if ((*it1)->IsZombie() && (*it2)->GetTypeid() == TYPEID_PEA && CollisionHappen)
        {
          (*it1)->SetHp((*it1)->GetHp() - 20);
          (*it2)->SetHp(HP_DEAD);
        }
        if ((*it1)->GetTypeid() == TYPEID_PEA && (*it2)->IsZombie() && CollisionHappen)
        {
          (*it1)->SetHp(HP_DEAD);
          (*it2)->SetHp((*it2)->GetHp() - 20);
        }

        if ((*it1)->IsZombie() && (*it2)->GetTypeid() == TYPEID_EXPLOSION && CollisionHappen)
        {
          (*it1)->SetHp(HP_DEAD);
        }
        if ((*it1)->GetTypeid() == TYPEID_EXPLOSION && (*it2)->IsZombie() && CollisionHappen)
        {
          (*it2)->SetHp(HP_DEAD);
        }

        if ((*it1)->IsZombie() && (*it2)->IsPlant() && CollisionHappen)
        {

          (*it1)->Collision();
          (*it2)->SetHp((*it2)->GetHp() - 3);
        }
        if ((*it1)->IsPlant() && (*it2)->IsZombie() && CollisionHappen)
        {
          (*it1)->SetHp((*it1)->GetHp() - 3);
          (*it2)->Collision();
        }
      }
    }
  }

  for (auto it = objects.begin(); it != objects.end();)
  {
    if ((*it)->GetHp() <= HP_DEAD)
    {
      it = objects.erase(it);
    }
    else
    {
      it++;
    }
  }

  for (auto it = objects.begin(); it != objects.end(); ++it)
  {
    if ((*it)->IsZombie())
    {
      if ((*it)->GetX() < 0)
      {
        return LevelStatus::LOSING;
      }
    }
  }

  for (auto it1 = objects.begin(); it1 != objects.end(); it1++)
  {
    if ((*it1)->IsZombie())
    {
      bool CollisionHappen = false;
      for (auto it2 = objects.begin(); it2 != objects.end(); it2++)
      {
        if ((*it2)->IsPlant())
        {
          if (CollisionJudge((*it1)->GetX(), (*it1)->GetY(), (*it1)->GetWidth(), (*it1)->GetHeight(), (*it2)->GetX(), (*it2)->GetY(), (*it2)->GetWidth(), (*it2)->GetHeight()))
          {
            CollisionHappen = true;
            break;
          }
        }
      }
      if (!CollisionHappen)
      {
        (*it1)->CollisionOver();
      }
    }
  }

  return LevelStatus::ONGOING;
}

void GameWorld::CleanUp()
{
  objects.clear();
}

int GameWorld::GetTick() const
{
  return m_tick;
}
void GameWorld::TickUp()
{
  m_tick++;
}
int GameWorld::GetHandType() const
{
  return m_hand_type;
}
void GameWorld::SetHandType(int handtype = TYPEID_HAND)
{
  m_hand_type = handtype;
}

void GameWorld::Ctor(int x, int y, int type)
{
  const pGameWorld ptr = shared_from_this();
  switch (type)
  {
  case TYPEID_SUNFLOWER:
  case TYPEID_SUNFLOWERSEED:
  {
    objects.push_back(std::make_shared<Sunflower>(x, y, shared_from_this(), GetTick()));
    break;
  }
  case TYPEID_PEASHOOTER:
  case TYPEID_PEASHOOTERSEED:
  {
    objects.push_back(std::make_shared<Peashooter>(x, y, shared_from_this()));
    break;
  }
  case TYPEID_WALLNUT:
  case TYPEID_WALLNUTSEED:
  {
    objects.push_back(std::make_shared<Wallnut>(x, y, shared_from_this()));
    break;
  }
  case TYPEID_CHERRYBOMB:
  case TYPEID_CHERRYBOMBSEED:
  {
    objects.push_back(std::make_shared<CherryBomb>(x, y, shared_from_this()));
    break;
  }
  case TYPEID_REPEATER:
  case TYPEID_REPETAERSEED:
  {
    objects.push_back(std::make_shared<Repeater>(x, y, shared_from_this()));
    break;
  }
  case TYPEID_REGULAR:
  {
    objects.push_back(std::make_shared<RegularZombie>(x, y, shared_from_this()));
    break;
  }
  case TYPEID_BUCKETHEAD:
  {
    objects.push_back(std::make_shared<BucketHeadZombie>(x, y, shared_from_this()));
    break;
  }
  case TYPEID_POLEVAULTING:
  {
    objects.push_back(std::make_shared<PoleVaultingZombie>(x, y, shared_from_this()));
    break;
  }
  case TYPEID_SKYSUN:
  {
    objects.push_back(std::make_shared<Sun>(x, y, type, shared_from_this(), randInt(63, 263), GetTick()));
    break;
  }
  case TYPEID_SUNFLOWERSUN:
  {
    objects.push_back(std::make_shared<Sun>(x, y, type, shared_from_this(), 12, GetTick()));
    break;
  }
  case TYPEID_PEA:
  {
    objects.push_back(std::make_shared<Pea>(x, y, shared_from_this()));
    break;
  }
  case TYPEID_EXPLOSION:
  {
    objects.push_back(std::make_shared<Explosion>(x, y, shared_from_this()));
    break;
  }
  case TYPEID_PLANTINGSPOT:
  {
    objects.push_back(std::make_shared<PlantingSpot>(x, y, shared_from_this()));
    break;
  }
  default:
    break;
  }
}
void GameWorld::Ctor(int x, int y, int type, int cdtick)
{
  if (type == TYPEID_COOLDOWNMASK)
  {
    objects.push_back(std::make_shared<CooldownMask>(x, y, shared_from_this(), cdtick, GetTick()));
  }
}

bool GameWorld::HaveZombie(int x, int y)
{
  for (auto it = objects.begin(); it != objects.end(); it++)
  {
    if ((*it)->GetTypeid() == TYPEID_REGULAR || (*it)->GetTypeid() == TYPEID_BUCKETHEAD || (*it)->GetTypeid() == TYPEID_POLEVAULTING)
    {
      if ((*it)->GetX() > x && (*it)->GetY() == y)
      {
        return true;
      }
    }
  }
  return false;
}

bool GameWorld::CollisionJudge(int x1, int y1, int width1, int height1, int x2, int y2, int width2, int height2)
{
  return ((x1 + width1 / 2) > (x2 - width2 / 2)) && ((x2 + width2 / 2) > (x1 - width1 / 2)) && ((y1 + height1 / 2) > (y2 - height2 / 2)) && ((y2 + height2 / 2) > (y1 - height1 / 2));
}

bool GameWorld::CollisionBtwPZ(int x, int y) const
{
  for (auto it = objects.begin(); it != objects.end(); it++)
  {
    if ((*it)->IsPlant())
    {
      if (((*it)->GetY() == y)&&((*it)->GetX()+(*it)->GetWidth()/2>=x))
      {
        return true;
      }
    }
  }
  return false;
}

// GameWorld::objects.push_back(state);
