#ifndef GAMEWORLD_HPP__
#define GAMEWORLD_HPP__

#include <list>
#include <memory>

#include "WorldBase.hpp"
#include "utils.hpp"

#include "GameObject.hpp"



class GameWorld : public WorldBase, public std::enable_shared_from_this<GameWorld> {
public:
  // Use shared_from_this() instead of "this".
  GameWorld();
  virtual ~GameWorld();

  void Init() override;

  LevelStatus Update() override;

  void CleanUp() override;

  int GetTick()const;
  void TickUp();

  int GetHandType()const;
  void SetHandType(int);

  void Ctor(int x, int y, int type);
  void Ctor(int,int,int,int);

  bool HaveZombie(int x,int y);

  bool CollisionJudge(int x1, int y1, int width1, int height1, int x2, int y2, int width2, int height2);
  bool CollisionBtwPZ(int x,int y) const;

private: 
  std::list<std::shared_ptr<GameObject>> objects;
  int m_tick;
  int m_hand_type;
  int m_waiting_time;
  int m_NextWave_tick;

};


#endif // !GAMEWORLD_HPP__
